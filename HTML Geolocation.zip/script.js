const box = document.getElementById("box");
const btnGet = document.getElementById("btnGet");
const btnStart = document.getElementById("btnStart");
const btnStop = document.getElementById("btnStop");

let watchID = null;

// ===============================
// 1. Lấy vị trí 1 lần
// ===============================
btnGet.onclick = function () {
    if (!navigator.geolocation) {
        box.innerHTML = "Trình duyệt không hỗ trợ Geolocation.";
        return;
    }

    const options = {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0
    };

    navigator.geolocation.getCurrentPosition(showPosition, showError, options);
};

// ===============================
// 2. Hiển thị Position
// ===============================
function showPosition(pos) {
    const c = pos.coords;

    box.innerHTML =
        `<b>📍 DỮ LIỆU VỊ TRÍ</b><br>
        Latitude: ${c.latitude}<br>
        Longitude: ${c.longitude}<br>
        Accuracy: ${c.accuracy} m<br>
        Altitude: ${c.altitude}<br>
        Altitude Accuracy: ${c.altitudeAccuracy}<br>
        Heading: ${c.heading}<br>
        Speed: ${c.speed}<br>
        Timestamp: ${new Date(pos.timestamp).toLocaleString()}`;
}

// ===============================
// 3. Xử lý lỗi PositionError
// ===============================
function showError(err) {
    let msg = "";

    switch (err.code) {
        case err.PERMISSION_DENIED:
            msg = "❌ Người dùng từ chối chia sẻ vị trí.";
            break;
        case err.POSITION_UNAVAILABLE:
            msg = "⚠️ Không thể xác định vị trí.";
            break;
        case err.TIMEOUT:
            msg = "⏱️ Hệ thống lấy vị trí quá lâu (timeout).";
            break;
        default:
            msg = "Lỗi không xác định.";
    }

    box.innerHTML = `<b>Lỗi:</b> ${msg}`;
}

// ===============================
// 4. Theo dõi vị trí liên tục
// ===============================
btnStart.onclick = function () {
    if (!navigator.geolocation) {
        box.innerHTML = "Trình duyệt không hỗ trợ Geolocation.";
        return;
    }

    const options = {
        enableHighAccuracy: true,
        timeout: 7000,
        maximumAge: 0
    };

    box.innerHTML = "🔄 Đang theo dõi vị trí...";
    watchID = navigator.geolocation.watchPosition(showPosition, showError, options);
};

// ===============================
// 5. Dừng theo dõi
// ===============================
btnStop.onclick = function () {
    if (watchID !== null) {
        navigator.geolocation.clearWatch(watchID);
        box.innerHTML = "🛑 Đã dừng theo dõi vị trí.";
    }
};
